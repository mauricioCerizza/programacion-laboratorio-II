﻿using Business;
using System;

namespace Presentation
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.ReadKey();
        }
    }
}
